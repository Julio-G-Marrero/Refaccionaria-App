<?php
if (!defined('ABSPATH')) {
    exit; // Evita acceso directo
}

// Archivo product-sync.php reservado para la sincronización con WooCommerce.
